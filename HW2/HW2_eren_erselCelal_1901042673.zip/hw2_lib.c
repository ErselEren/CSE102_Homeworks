/*
** hw2_lib.c:
**
** The source file implementing library functions.
**
*/

#include <stdio.h>
#include "hw2_lib.h"
#include <math.h>

int find_weekday_of_data(int day, int month, int year)
{
        /*=======================================================================  
	=  Zeller's Rule                                                        =
	=  F=k+ [(13*m-1)/5] +C+ [C/4] +[D/4]-2*D    ----> Formül               =
	=  k is the day of the month.                                           =
	=  m is the month number.                                               =
	=  D is the last two digits of the year.                                =
	=  C is the first two digits of the year.                               =
        =======================================================================*/   
        
        /* Formül için gerekli değişkenler  */
        int k;
        int m;
        int D;
        int C;
        int F;                                
        /*Yılın ilk ve son 2 rakamlarının hesaplanması için değişkenler tanımlandı */
        int D1;
        int D2;
        int C1;
        int C2;  
        
        /* Artık yıl kontrolü */
        int control_leap_year;
        control_leap_year = 0;
        if(((year % 4 == 0) && (year % 100!= 0))||(year%400 == 0))
        control_leap_year = 1;
        /*--------------------*/
        
        /*----------------------------------------------------------------------*/
        if((month==1||month==3||month==5||month==7||month==8||month==10||month==12)&&day>31){
            printf("%d. month doesn't have more than 31 days\n",month);
        }
        else if((month==4||month==6||month==9||month==11)&&day>30){
            printf("%d. month doesn't have more than 30 days\n",month);
        }   
        else if((month==2)&&control_leap_year&&(day>29)||(month==2)&&(day>28)&&(control_leap_year==0)){
            printf("You have entered wrong day input for %d. month\n",month);
        }
        else{
        /*---------------------------------------------------------------------*/
        /* ------------ Ocak ve Şubat ayları için kurala göre düzenleme--------*/
	if(month==1||month==2){
		year=year-1;
		month=month+10;
	}
	else{
	    month=month-2;	
	}
	/*---------------------------------------------------------------------*/
	k=day;
	m=month;
	
	/*---------Yılın ilk ve son 2 basamaklarının hesaplanması---------*/
	D1=year/1000;                           /* İlk rakam */
        D2=(year-D1*1000)/100;                  /* İkinci rakam */
        C1=(year-(D1*1000)+(D2*100))/10;        /* İlk rakam */
        C2=(year-((D1*1000)+(D2*100)+C1*10))/1; /* İkinci rakam */
        D = (D1*10)+D2;
        C = (C1*10)+C2;

	/*-------------------------Formülün uygulanışı-------------------------*/
	F=k+ (13*m-1)/5 +C+C/4 +D/4-2*D; 
	
	if(F<0){
	    do{
	     F=F+7;
	    }while(F<=0);
	}
	else if(F>=0){
	    F = F%7;	
	}
	
	printf("Day is : ");
	/* Monday = 1, Tuesday=2 olmak üzere bulunan değerler return ediliyor */
	if(F==0){
		printf("Sunday\n");
		return 7;	
	}
	else if(F==1){
		printf("Monday\n");
		return 1;
	}
	else if(F==2){
		printf("Tuesday\n");
		return 2;
	}
	else if(F==3){
		printf("Wednesday\n");
		return 3;
	}
	else if(F==4){
		printf("Thursday\n");
		return 4;
	}
	else if(F==5){
		printf("Friday\n");
		return 5;
	}
	else if(F==6){
		printf("Saturday");
		return 6;
	}       
    }
        	
}


int count_day_between_dates(int start_day, int start_month, int start_year, int end_day, int end_month, int end_year)
{
    int days_of_month[13]={0,31,28,31,30,31,30,31,31,30,31,30,31}; /*Günler diziye atandı */
    int sum=0;   /* toplamlar sum, sum0 ve sum1 değişkenlerine atanacak */ 
    int sum0=0; 
    int sum1=0;
    int i;
    int count_leap_year=0; 
    
	/* başlangıç ve bitiş yılları arasındaki günlerin toplamı */
	sum = ((end_year-start_year)-1)*365; 
	for(i=start_year+1;i<end_year;i++){
	    if(((i % 4 == 0) && (i % 100!= 0)) || (i%400 == 0)){    /* Başlangıç ve bitiş yılı arasındaki artık yılların kontrolü */
		count_leap_year = count_leap_year + 1; 
	    }
	}  
	/*--------------------------------------------------------*/
	/*--------------------------------------------------------*/
	
	/* başlangıç yılındaki günlerin toplamı */
	for(i=1;i<start_month;i++){
		sum0 = sum0 + days_of_month[i];	
	}
		sum0 = sum0 + start_day;
		sum0 = 365 - sum0;
	/*--------------------------------------*/	
	/*--------------------------------------*/	

	/* başlangıç yılı artık yıl ve tarih mart'tan önce ise 1 eklenir */
	if(((start_year % 4 == 0) && (start_year % 100!= 0)) || (start_year%400 == 0))
	{
		if(start_month<1){
		   sum0=sum0+1; 
		}
	}
	/*----------------------------------------------------------------*/
	/*----------------------------------------------------------------*/
	
        /*Bitiş yılındaki günlerin hesaplanması */
        for(i=1;i<end_month;i++){
		sum1 = sum1 + days_of_month[i];
	}
	    sum1 = sum1 + end_day;
	if(((end_year % 4 == 0) && (end_year % 100!= 0)) || (end_year%400 == 0))
	{
		if(end_month>1){
			sum1 = sum1 +1;
		}
	}
	/*------------------------------------------------------------------------*/
	/*------------------------------------------------------------------------*/
	
	/* her hesaplama farklı değişkenlerde toplandı ve son olarak sum değişkenine atandı */
	sum = sum + sum0 + sum1 + count_leap_year;
	printf("There are %d days between\n",sum);
	return sum;
}


double find_angle(double a, double b, double c)
{
       
        /* Kosinüs teoremi ve kenarortay teoremi ile hesaplama */
        double upper_angle, lower_left_angle_half, lower_right_angle_half, BE, CG, result;
	
	upper_angle= acos((pow(a,2)-(pow(b,2)+pow(c,2)))/(-2*b*c)); /*ters trigonometrik fonksiyonlardan yararlanılıyor*/
	
	BE= sqrt((pow(b,2)+pow(c/2,2))-(2*b*(c/2)*cos(upper_angle))); 
	
	lower_left_angle_half= acos((pow(c/2,2)-(pow(BE,2)+pow(a,2)))/(-2*BE*a))*57.29578; 

	CG= sqrt((pow(b/2,2)+pow(c,2))-(2*c*(b/2)*cos(upper_angle)));
	
	lower_right_angle_half= acos((pow(b/2,2)-(pow(a,2)+pow(CG,2)))/(-2*CG*a))*57.29578;
	
	result= 180-(lower_left_angle_half+lower_right_angle_half); 
	
    printf(" Result is : %f\n",result);
    return result;
}


void print_tabulated(unsigned int r11, double r12, int r13, 
                     unsigned int r21, double r22, int r23, 
                     unsigned int r31, double r32, int r33, char border)
{
  
  int count11,count12,count13;
  int ctr_r11,ctr_r12,ctr_r13;
  int i,j,t;
  i=1;
  j=1;
  t=1;
  /*------------------------------------------------------------------------*/
    ctr_r11=r11;
    ctr_r12=r12;
    ctr_r13=r13;
  /*------------------------------------------------------------------------*/
  count11=0; /* 1.kolon 1.satır */
  count12=0; /* 2.kolon 1.satır */
  count13=0; /* 3.kolon 1.satır */ 
  /*-------------------------------------------------------------------------*/
  while(ctr_r11!=0){
  ctr_r11=ctr_r11/10;    /* r11'in basamak sayısını hesaplar */
  count11++;
  }
  
  while(ctr_r12!=0){
  ctr_r12=ctr_r12/10;    /* r12'in basamak sayısını hesaplar */
  count12++;
  }
  
  while(ctr_r13!=0){
  ctr_r13=ctr_r13/10;    /* r13'in basamak sayısını hesaplar */
  count13++;
  }
  
  /*--------------------------------------------------------------------------*/
  
  printf(" ");
  for(i=0;i<47;i++){           /* tablonun üst kevnarının çizgileri */
    printf("_");            
  } 
  printf("\n");
  printf("⎡            ⎢                  ⎢               ⎤\n");
  printf("⎢  Row 101   ⎢   Row ABCDEFFG   ⎢   Row XYZ123  ⎥\n");       
  printf("⎢------------⎢------------------⎢---------------⎥\n");
  printf("⎢");
  switch(count11)
  {
    case 1:
        for(i=0;i<5;i++){
           printf(" ");
        }
        printf("%u",r11);
        for(i=0;i<6;i++){
           printf(" ");
        }
        break;
    case 2:
        for(i=0;i<5;i++){
           printf(" ");
        }
        printf("%u",r11);
        for(i=0;i<5;i++){
           printf(" ");
        }
        break;
     case 3:
        for(i=0;i<5;i++){
           printf(" ");
        }
        printf("%u",r11);
        for(i=0;i<4;i++){
           printf(" ");
        }
        break; 
     case 4:
        for(i=0;i<4;i++){
           printf(" ");
        }
        printf("%u",r11);
        for(i=0;i<4;i++){
           printf(" ");
        }
        break;         
  }
  printf("⎢");
  /*------------------------------------------------------------------------*/
  /*------------------------------------------------------------------------*/
  /*------------------------------------------------------------------------*/  
  /*------------------------------------------------------------------------*/
    if(r12<0)
    {
     j=j+1;
    }
     
    if(count12==5){
         printf("%7.2f",r12);
            for(j;j<=10;j++)
            {
             printf(" ");
            }         
    }    
    
    else if(count12==4){  
           printf("%6.2f",r12);
               for(j;j<=11;j++)
               {
                printf(" ");
               }
    }
    
    else if(count12==3){   
           printf("%5.2f",r12);
              for(j;j<=12;j++)
              {
               printf(" ");
              }
    } 
    
    else if(count12==2){   
           printf("%4.2f",r12);
           for(j;j<=13;j++)
           {
            printf(" ");
           }
    }
    
    else if(count12==1){   
           printf("%3.2f",r12);
               for(j;j<=14;j++)
               { 
                printf(" ");
               }
    }
    
    else if(count12==0){   
           printf("%2.2f",r12);
              for(j;j<=15;j++)
              {
               printf(" ");
              }
    }
    printf("⎢");
  /*------------------------------------------------------------------------*/
  /*------------------------------------------------------------------------*/
  /*------------------------------------------------------------------------*/  
  /*------------------------------------------------------------------------*/
  if(r13>0){
    printf("+");
  }  
   
    
    if(count13==5)
    {
        printf("%d",r13);
           for(t;t<=14-count13;t++){
           printf(" ");
           }
    }    
    
    else if(count13==4)
    {  
        printf("%d",r13);
           for(t;t<=14-count13;t++){
           printf(" ");
           }
    }
    
    else if(count13==3)
    {   
        printf("%d",r13);
           for(t;t<=14-count13;t++){
           printf(" ");
           }
    } 
    
    else if(count13==2)
    {   
        printf("%d",r13);
           for(t;t<=14-count13;t++){
           printf(" ");
           }
    }
    
    else if(count13==1)
    {   
        printf("%d",r13);
           for(t;t<=14-count13;t++){
           printf(" ");
           }
    }
    
    else if(count13==0)
    {   
        printf("%d",r13);
           for(t;t<=14-count13;t++){
           printf(" ");
           }
    }
   
  printf("⎥\n");      
  printf("⎣____________⎢__________________⎢_______________⎦\n");
  printf("\n\n"); 
}

