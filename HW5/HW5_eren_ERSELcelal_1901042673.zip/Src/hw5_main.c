/*
** main.c:
**
** The test/driver program for the homework.
**
** Author: Yakup Genc. (c) 2018-2021
**
** Revision: 2021.04.02.23.55
** 
*/


#include <stdio.h>
#include "hw5_lib.h"


void test_operate_polynomials () 
{
	double c1_0,c1_1,c1_2,c1_3; /*coefficients of first polynomial*/
    int d1_0,d1_1,d1_2,d1_3; /* degrees of first polynomial */
    double c2_0,c2_1,c2_2,c2_3; /*coefficients of second polynomial*/
    int d2_0,d2_1,d2_2,d2_3;	/* degrees of second polynomial */
    double a0,a1,a2,a3,b3,b2,b1,b0; /* we send this variables to function */
	int flag;
	char op;
	char avoid;
	flag = 1;
	

	printf("\nEnter coefficients of each degree of 1.polynomial -> (degree, coef), (degree, coef),... ");
    scanf("(%d, %lf), (%d, %lf), (%d, %lf), (%d, %lf)",&d1_0, &c1_0, &d1_1, &c1_1, &d1_2, &c1_2, &d1_3, &c1_3);
    /* printf("\n(%d, %lf),(%d, %lf),(%d, %lf),(%d, %lf)",d1_0, c1_0, d1_1, c1_1, d1_2, c1_2, d1_3, c1_3); */
    avoid = getchar(); /* to avoid 'ENTER' */
	printf("\nEnter coefficients of each degree of 2.polynomial -> (degree, coef), (degree, coef),... ");
    scanf("(%d, %lf), (%d, %lf), (%d, %lf), (%d, %lf)",&d2_0,&c2_0,&d2_1,&c2_1,&d2_2,&c2_2,&d2_3,&c2_3);
    /* printf("\n(%d, %lf),(%d, %lf),(%d, %lf),(%d, %lf)",d2_0,c2_0,d2_1,c2_1,d2_2,c2_2,d2_3,c2_3); */
	avoid = getchar(); /* to avoid 'ENTER' */
    
	/*For first polynomial 0. degree */
	if(d1_1 == 0)
	   a0 = c1_1;
	else if(d1_2 == 0)
       a0 = c1_2;
	else if(d1_3 == 0)
	   a0 = c1_3;
	else
	   a0 = c1_0;
   
	/*For first polynomial 1. degree */
	if(d1_0 == 1)
	   a1 = c1_0;
	else if(d1_2 == 1)
       a1 = c1_2;
	else if(d1_3 == 1)
	   a1 = c1_3;
	else
	   a1 = c1_1;
	
	/*For first polynomial 2. degree */
	if(d1_0 == 2)
	   a2 = c1_0;
	else if(d1_1 == 2)
       a2 = c1_1;
	else if(d1_3 == 2)
	   a2 = c1_3;
	else 
	   a2 = c1_2;

	/*For first polynomial 3. degree */
	if(d1_0 == 3)
	   a3 = c1_0;
	else if(d1_1 == 3)
       a3 = c1_1;
	else if(d1_2 == 3)
	   a3 = c1_2;
	else
	   a3 = c1_3;
	
	printf("\n a0 = %lf, a1 =  %lf, a2 =  %lf, a3 =  %lf",a0,a1,a2,a3);
    /*================================================================*/
	/*================================================================*/
	
	/*For second polynomial 0. degree */
	if(d2_1 == 0)
	   b0 = c2_1;
	else if(d2_2 == 0)
       b0 = c2_2;
	else if(d2_3 == 0)
	   b0 = c2_3;
	else
	   b0 = c2_0;
   
	/*For second polynomial 1. degree */
	if(d2_0 == 1)
	   b1 = c2_0;
	else if(d2_2 == 1)
       b1 = c2_2;
	else if(d2_3 == 1)
	   b1 = c2_3;
	else
	   b1 = c2_1;
	
	/*For second polynomial 2. degree */
	if(d2_0 == 2)
	   b2 = c2_0;
	else if(d2_1 == 2)
       b2 = c2_1;
	else if(d2_3 == 2)
	   b2 = c2_3;
	else 
	   b2 = c2_2;

	/*For second polynomial 3. degree */
	if(d2_0 == 3)
	   b3 = c2_0;
	else if(d2_1 == 3)
       b3 = c2_1;
	else if(d2_2 == 3)
	   b3 = c2_2;
	else
	   b3 = c2_3;

	printf("\n b0 = %lf, b1 =  %lf, b2 =  %lf, b3 =  %lf",b0,b1,b2,b3);
	
	
	printf("\nEnter an operator (+ , - , * ): ");
	
	while(flag==1){ 
	   scanf("%c", &op);
	   if(op=='+'||op=='-'||op=='*'){
         flag = 0;
	   }
       else{
		   printf("\nEnter a VALID operator : ");
	   }  
	}
    	
	operate_polynomials(&a3,&a2,&a1,&a0,&b3,&b2,&b1,&b0,op);

	if(op=='*'){
		printf(" Degree>>> x^6 = %.3lf, x^5 = %.3lf, x^4 = %.3lf, x^3 = %.3lf, x^2 = %.3lf, x^1 = %.3lf, x^0 = %.3lf",a3,a2,a1,a0,b3,b2,b1);
	}
	if(op=='+'||op=='-'){
		printf("x^3 = %.3lf, x^2 = %.3lf, x^1 = %.3lf, x^0 = %.3lf",a3,a2,a1,a0);
	}
	
}

void test_four_d_vectors ()
{
	double mean_a0=0.0, mean_a1=0.0, mean_a2=0.0, mean_a3=0.0, longest_distance=0.0;
	int N=5;
	four_d_vectors (&mean_a0, &mean_a1, &mean_a2, &mean_a3, &longest_distance, N);
	printf("Mean a0: %f\nMean a1: %f\nMean a2: %f\nMean a3: %f\nThe longest distance between two points: %f\n\n\n", mean_a0, mean_a1, mean_a2, mean_a3, longest_distance);
}

void test_order_2d_points_cc ()
{
	double x1=2, y1=-1, x2=1, y2=-2, x3=-2, y3=-3;
	order_2d_points_cc (&x1, &y1, &x2, &y2, &x3, &y3);
	printf("Counter-Clockwise Order: (%f,%f) - (%f,%f) - (%f,%f)\n\n\n", x1, y1, x2, y2, x3, y3);
}

void test_number_encrypt ()
{
	unsigned char number=125;
	number_encrypt (&number);
	printf("Encrypted number: %d\n\n\n", number);
}

void test_dhondt_method ()
{
	int partyA=10000, partyB=20000, partyC=30000, partyD=80000, partyE=100000, numberOfSeats=550;
	dhondt_method (&partyA, &partyB, &partyC, &partyD, &partyE, numberOfSeats);
	printf("Party A: %d seat(s).\nParty B: %d seat(s).\nParty C: %d seat(s).\nParty D: %d seat(s).\nParty E: %d seat(s).\n\n\n", partyA, partyB, partyC, partyD, partyE);
}


/*
** main function for testing the functions...
**
*/
int main(void) {
	/*
	test_operate_polynomials ();
	test_four_d_vectors ();
	test_order_2d_points_cc ();
	test_dhondt_method ();
	test_number_encrypt (); 
	*/
    test_operate_polynomials ();
	return 0;
} /* end main */
