/*
** hw5_lib.c:
**
** The source file implementing library functions.
**
** Author: Yakup Genc. (c) 2018-2021
**
** Revision: 2021.04.02.23.55
** 
*/

#include <stdio.h>
#include "hw5_lib.h"
#include <math.h>

void operate_polynomials  (double* a3, double* a2, double* a1, double* a0, double* b3, double* b2, double* b1, double* b0, char op)
{
	/* we get inputs in hw5_main.c --> test_operate_polynomials function */
	
	if(op == '+'){
		*a3 = *a3 + *b3;
		*a2 = *a2 + *b2;
		*a1 = *a1 + *b1;
		*a0 = *a0 + *b0;
	}
	if(op == '-'){
		*a3 = *a3 - *b3;
		*a2 = *a2 - *b2;
		*a1 = *a0 - *b1;
		*a0 = *a0 - *b0;
	}
	if(op == '*'){
	
	 double c6,c5,c4,c3,c2,c1,c0;  /* variables to store coef of degrees */
     
     /* assigning coefs to 'c' values */
     /* 6 */ c6 = (*a3)*(*b3);
     /* 5 */ c5 = (*a2)*(*b3) + (*a3)*(*b2);
     /* 4 */ c4 = (*a1)*(*b3) + (*a3)*(*b1) + (*a2)*(*b2);
     /* 3 */ c3 = (*a3)*(*b0) + (*a2)*(*b1) + (*b2)*(*a1) + (*b3)*(*a0);
     /* 2 */ c2 = (*a2)*(*b0) + (*b2)*(*a0) + (*b1)*(*a1);
     /* 1 */ c1 = (*a1)*(*b0) + (*b1)*(*a0);
     /* 0 */ c0 = (*a0)*(*b0);

     /* reassign for returning values to main */
     *a3 = c6;
     *a2 = c5;
     *a1 = c4;
     *a0 = c3;
     *b3 = c2;
     *b2 = c1;
     *b1 = c0;

	}
}

void four_d_vectors (double* mean_a0, double* mean_a1, double* mean_a2, double* mean_a3, double* longest_distance, int N)
{
	
	double d0, d1, d2, d3, euclidian_distance;
	double f0,f1,f2,f3; /* first vector  */
	double s0,s1,s2,s3; /* second vector */
	int flag,i;  /* for control and counter */
    /* initializing */
	flag = 1;
	i = 1;
	*longest_distance = 0;
	
	/* getting dimensions of first vector */
	printf("Enter values of %d. vector : ",i);
	scanf("%lf %lf %lf %lf",&f0,&f1,&f2,&f3);
	*mean_a0 = f0;  *mean_a1 = f1;  *mean_a2 = f2;  *mean_a3=f3; /* assigning values to mean */
	
	do{
      /* getting dimensions of second vector */
	  printf("\nEnter values of %d. vector : ",i+1);
	  scanf("%lf %lf %lf %lf",&s0,&s1,&s2,&s3);
	  
	  /* checking -1-1-1-1 and equal to N condition */
	  if(i==N-1||(s0==-1&&s1==-1&&s2==-1&&s3==-1))
	       flag = 0;
	  
	  if(flag==1){ 
		 /* assignin values to mean variables to calculate average */
		 *mean_a0 += s0;  *mean_a1 += s1;  *mean_a2 += s2;  *mean_a3+= s3;

		  /* for calculating euclidian distance */
	  	  d0 = f0 - s0;
	  	  d1 = f1 - s1;
	  	  d2 = f2 - s2;
	  	  d3 = f3 - s3;
		  distance_between_4d_points (d0, d1, d2, d3, &euclidian_distance);
		  if(*longest_distance<euclidian_distance)
		     *longest_distance=euclidian_distance;
		  printf("Difference between last two vector : %lf\n\n",euclidian_distance);
	  	  
		  /* for consecutive calculation we change the variables */
		  f0 = s0;
	  	  f1 = s1;
	  	  f2 = s2;
	  	  f3 = s3;
      	  
		  i++;
	    }
	    	  	
	}while(flag!=0);

	/* calculating average of each dimension */
	*mean_a0 = *mean_a0/i;
	*mean_a1 = *mean_a1/i;
	*mean_a2 = *mean_a2/i;
	*mean_a3 = *mean_a3/i;

	
	distance_between_4d_points(d0, d1, d2, d3, &euclidian_distance);
}

void distance_between_4d_points (double d0, double d1, double d2, double d3, double* euclidian_distance)
{
    *euclidian_distance = sqrt((d0*d0)+ (d1*d1) + (d2*d2) + (d3*d3));	
}

int find_max(int* pA,int* pB,int* pC,int* pD,int* pE, int* seat_A,int* seat_B,int* seat_C,int* seat_D,int* seat_E, int* ind){
	
	int max_vote,max_seat; /* we compare max_vote and max_seat values with party's votes and seats */
	/* at the beginning we assign partyA to max values and compare it */
	max_vote = *pA;
	max_seat = *seat_A;
	*ind = 1; /* index indicates party that we should give seat to it */
		
	if(*pB>=max_vote){
		if(*pB==max_vote){ /* if votes are equal, we check given seats  */
           if(max_seat < *seat_B){ 
		   }
		   else{ /* if given seats to this party are less than max_seat, we change max_vote and max_seat */
			  max_vote = *pB;
              max_seat = *seat_B;
			  *ind = 2;
		   }
		}
		else{  /* if votes are not equal, it must be higher, so we assign new values */
            max_vote = *pB;
            max_seat = *seat_B;
			*ind = 2;
		}
	}
	if(*pC>=max_vote){
		if(*pC==max_vote){ 
           if(max_seat < *seat_C){ 
		   }
		   else{
			  max_vote = *pC;
              max_seat = *seat_C;
			  *ind = 3;
		   }
		}
		else{ 
            max_vote = *pC;
            max_seat = *seat_C;
			*ind = 3;
		}
	}
	if(*pD>=max_vote){
		if(*pD==max_vote){ 
           if(max_seat < *seat_D){ 
		   }
		   else{
			  max_vote = *pD;
              max_seat = *seat_D;
			  *ind = 4;
		   }
		}
		else{ 
            max_vote = *pD;
            max_seat = *seat_D;
			*ind = 4;
		}
	}
	if(*pE>=max_vote){
		if(*pE==max_vote){ 
           if(max_seat < *seat_E){ 
		   }
		   else{
			  max_vote = *pE;
              max_seat = *seat_E;
			  *ind = 5;
		   }
		}
		else{ 
            max_vote = *pE;
            max_seat = *seat_E;
			*ind = 5;
		}
	}     
}

void dhondt_method (int* partyA, int* partyB, int* partyC, int* partyD, int* partyE, int numberOfSeats)
{
	int org_A, org_B, org_C, org_D, org_E;  /* holding original values to use later */
	int count_A;int count_B;int count_C;int count_D;int count_E; /* counting seats and dividing votes */
	int index,max,i; /* other required variables for function */ 
	
	/* assignin original values to divide every step*/
	org_A = *partyA;
    org_B = *partyB;
    org_C = *partyC;
	org_D = *partyD;
    org_E = *partyE;
	/* we give a seat to every party, we'll substract 1 in the end */
	count_A=1; count_B=1; count_C=1;count_D=1; count_E=1;
	
	/* for every available seat, we send values to find_max function which returns 
	   index of party that we need to give seat according to votes and given seats */
	for(i=0;i<numberOfSeats;i++){
		find_max(partyA,partyB,partyC,partyD,partyE,&count_A,&count_B,&count_C,&count_D,&count_E,&index);
        /* index 1 is for partyA , 2 is for B, 3 is C , 4 is D and 5 is E */
		if(index == 1){
          *partyA = org_A / (count_A+1);
		  count_A++;
		}
		if(index == 2){
		  *partyB = org_B / (count_B+1);
		  count_B++;
		}
		if(index == 3){
		  *partyC = org_C / (count_C+1);
		  count_C++;
		}
	    if(index == 4){
		  *partyD = org_D / (count_D+1);
		  count_D++;
		}
		if(index == 5){
		  *partyE = org_E / (count_E+1);
		  count_E++;
		}
	}
    
	/* here we subtract 1 from every party's seats and get the correct output */
	*partyA = count_A-1;
	*partyB = count_B-1;
	*partyC = count_C-1;
	*partyD = count_D-1;
	*partyE = count_E-1;
	
}

void order_2d_points_cc (double* x1, double* y1, double* x2, double* y2, double* x3, double* y3)
{
	double temp_x1,temp_x2,temp_x3,temp_y1,temp_y2,temp_y3; /* temporary values of points to use again */
	int section1,section2,section3; /*to indicate section of a point in coordinate plane */
	double slope1,slope2,slope3; /* to indicate slope of points */
	double angle1,angle2,angle3; /* final value that we compare*/
	
	temp_x1= *x1;  temp_x2= *x2;  temp_x3= *x3;  temp_y1= *y1;  temp_y2= *y2;  temp_y3= *y3;

	/* 
	Section 1 => x>0 , y>0 
	Section 2 => x<0 , y>0  
	Section 3 => x<0 , y<0  
	Section 4 => x>0 , y<0 
	*/
	
	/* Checking section of points */
	/*===========*/
	if(*x1>0&&*y1>0)
	  section1 = 1;
	if(*x1<=0&&*y1>0)
	  section1 = 2;
	if(*x1<0&&*y1<=0)
	  section1 = 3;
	if(*x1>=0&&*y1<0)
	  section1 = 4;
	/*===========*/
	if(*x2>0&&*y2>0)
	  section2 = 1;
	if(*x2<=0&&*y2>0)
	  section2 = 2;
	if(*x2<0&&*y2<=0)
	  section2 = 3;
	if(*x2>=0&&*y2<0)
	  section2 = 4; 
	/*===========*/  
	if(*x3>0&&*y3>0)
	  section3 = 1;
	if(*x3<=0&&*y3>0)
	  section3 = 2;
	if(*x3<0&&*y3<=0)
	  section3 = 3;
	if(*x3>=0&&*y3<0)
	  section3 = 4; 
	/*===========*/                       
    
	/* we find slope of points by dividing y axis to x axis */
	slope1 = (*y1)/(*x1);
	slope2 = (*y2)/(*x2);
	slope3 = (*y3)/(*x3);
    
	/* checking if points are 0 */
    if(*x1==0||*y1==0)
	  slope1 = 0;
	if(*x2==0||*y2==0)
	  slope2 = 0;
	if(*x3==0||*y3==0)
	  slope3 = 0;	      
    
    /* here we calculate angles according to section of points */
	if(section1 == 1)
	  angle1 = slope1;
	if(section1 == 2)
	  angle1 = slope1 + 90;
	if(section1 == 3)
	  angle1 = slope1 + 180;
	if(section1 == 4)
	  angle1 = slope1 + 270;
	/*====================*/
	if(section2 == 1)
	  angle2 = slope2;
	if(section2 == 2)
	  angle2 = slope2 + 90;
	if(section2 == 3)
	  angle2 = slope2 + 180;
	if(section2 == 4)
	  angle2 = slope2 + 270;
	/*====================*/
	if(section3 == 1)
	  angle3 = slope3;
    if(section3 == 2)
	  angle3 = slope3 + 90;
	if(section3 == 3)
	  angle3 = slope3 + 180;
	if(section3 == 4)
	  angle3 = slope3 + 270;
	/*====================*/
	
	/* here we assign the values from lower angle to higher angle by if else conditions */
    if(angle1>angle2&&angle1>angle3&&angle2>angle3){  /* 1>2>3 */
		*y3 = temp_y1;
		*x3 = temp_x1;
		*y2 = temp_y2;
		*x2 = temp_x2;
		*y1 = temp_y3;
		*x1 = temp_x3; 
	}
	else if(angle1>angle2&&angle1>angle3&&angle3>angle2){ /* 1>3>2 */
	    *y3 = temp_y1;
		*x3 = temp_x1;
		*y2 = temp_y3;
		*x2 = temp_x3;
		*y1 = temp_y2;
		*x1 = temp_x2; 
	}
	else if(angle2>angle1&&angle2>angle3&&angle1>angle3){ /* 2>1>3 */
	    *y3 = temp_y2;
		*x3 = temp_x2;
		*y2 = temp_y1;
		*x2 = temp_x1;
		*y1 = temp_y3;
		*x1 = temp_x3; 
	}
	else if(angle2>angle1&&angle2>angle3&&angle3>angle1){ /* 2>3>1 */
	    *y3 = temp_y2;
		*x3 = temp_x2;
		*y2 = temp_y3;
		*x2 = temp_x3;
		*y1 = temp_y1;
		*x1 = temp_x1; 
	}
	else if(angle3>angle1&&angle3>angle2&&angle1>angle2){ /* 3>1>2 */
		*y3 = temp_y3;
		*x3 = temp_x3;
		*y2 = temp_y1;
		*x2 = temp_x1;
		*y1 = temp_y2;
		*x1 = temp_x2; 
	}
	
}

void number_encrypt (unsigned char* number)
{
	char b7,b6,b5,b4,b3,b2,b1,b0; 	
	/* passing number and bit variables to convert number */
	get_number_components (*number, &b7, &b6, &b5, &b4, &b3, &b2, &b1, &b0);
	
	/* After converting we add algorithm to encryption */
	reconstruct_components (number, b7, b6, b5, b4, b3, b2, b1, b0);
}

void get_number_components (unsigned char number, char* b7, char* b6, char* b5, char* b4, char* b3, char* b2, char* b1, char* b0)
{
	int quot1,quot2,quot3,quot4,quot5,quot6,quot7,quot8; /* to store quotients */
    int rmd1,rmd2,rmd3,rmd4,rmd5,rmd6,rmd7,rmd8; /* to store remainders */
	int flag; /* if one of the quotients is 1, flag make program stop calculating */
	flag = 1;  
	quot1=0;quot2=0;quot3=0;quot4=0;quot5=0;quot6=0;quot7=0;quot8=0;
	rmd1=0;rmd2=0;rmd3=0;rmd4=0;rmd5=0;rmd6=0;rmd7=0;rmd8=0; 

	  /* here we start calculating */
	  /* dividing number to 2, get remainder and quotient */
	  /* if quotient is not 1, we continue to do this in every if else */ 
	  quot1 = number/2;
	  rmd8  = number%2;
      if(number/2 == 1 ){
		  rmd7 = 1;
		  flag = 0;
	  }

      if(flag == 1){
		  quot2 = quot1/2;
	      rmd7  = quot1%2;
	      if(quot2 == 1 ){
		     flag = 0;
		     rmd6 = 1;
	      }	
	  }
      
	  if(flag == 1){
		  quot3 = quot2/2;
	  	  rmd6  = quot2%2;
	  	  if(quot3 == 1 ){
		    rmd5 = 1;
			flag = 0;
	      }
	  }
	     
      if(flag == 1){
		  quot4 = quot3/2; 
	      rmd5  = quot3%2;
	      if(quot4 == 1 ){
		    rmd4 = 1;
			flag = 0;
	      }
	  } 
	  
	  if(flag == 1){
		  quot5 = quot4/2;
	      rmd4  = quot4%2;
	      if(quot5 == 1 ){
		    rmd3 = 1;
			flag = 0;
	      }
	  }
	     
      if(flag == 1){
		  quot6 = quot5/2;
	      rmd3  = quot5%2;
	      if(quot6 == 1 ){
		    rmd2 = 1;
			flag = 0;
	      }
	  }
	  
	  if(flag == 1){
		  quot7 = quot6/2;
	  	  rmd2  = quot6%2;
	  	  if(quot7 == 1 ){
		    rmd1 = 1;	
			flag = 0;
	      }
	  }
	     
      if(flag == 1){
		  quot8 = quot7/2;
	  	  rmd1  = quot7%2;
	  	  if(quot8 == 1 ){
		    rmd1 = quot8;
	      	flag = 0;
		  }
	  }
	  
	  /* after finishing calculation, we assign bit's to variables */
	  *b0=rmd1;  *b1=rmd2;  *b2=rmd3;  *b3=rmd4;  
	  *b4=rmd5;  *b5=rmd6;  *b6=rmd7;  *b7=rmd8;

}

void reconstruct_components (unsigned char* number, char b7, char b6, char b5, char b4, char b3, char b2, char b1, char b0)
{
    /* we create temp bit variables to have original values */
	int bit0,bit1,bit2,bit3,bit4,bit5,bit6,bit7; 
	
	/*encrypting number according to given algorithm */
	bit0 = b5; bit5 = b0; bit1 = b4; bit4 = b1; 
	bit2 = b7; bit7 = b2; bit3 = b6; bit6 = b3;
    
	b6 = bit0; b7 = bit1; b0 = bit2; b1 = bit3; 
	b2 = bit4; b3 = bit5; b4 = bit6; b5 = bit7;
    /*===============================================*/
	
	/* converting bit values to decimal number */
	*number = b7*1 + b6*2 + b5*4 + b4*8 + b3*16 + b2*32 + b1*64 + b0*128 ;

}
