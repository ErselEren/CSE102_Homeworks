

#include <stdio.h>
#include <stdlib.h>
#include "hw8_lib.h"
#define N 3

/*
  maze is working well.
  i have some clean_file codes but it's not done yet.So you don't need to test it
  there is no hanoi code 
*/

/*
  in maze function, I'm asking for P1 and P2 then asking direction of desired move	
*/

void test_clean_file () 
{
	char *infile = "input.txt";
	char *outfile = "output.txt";
	char *words_to_delete[N] = {"celal","hatice","busra"};
	int number_of_words = N; 
	clean_file(infile, outfile, words_to_delete, number_of_words);
}
void test_maze_move ()
{	
	move_type move;
	cell_type player;
	cell_type maze[8][8]=
	{
		{cell_wall, cell_wall, cell_wall, cell_target, cell_wall, cell_wall, cell_wall, cell_wall},
        {cell_wall, cell_free, cell_free, cell_free, cell_wall, cell_free, cell_free, cell_wall},
        {cell_wall, cell_free, cell_wall, cell_free, cell_free, cell_free, cell_wall, cell_wall},
        {cell_wall, cell_free, cell_wall, cell_free, cell_wall, cell_free, cell_free, cell_wall},
        {cell_wall, cell_free, cell_wall,   cell_wall, cell_p2,   cell_wall, cell_free, cell_wall},
        {cell_wall, cell_p1, cell_wall, cell_wall, cell_free, cell_wall, cell_free, cell_wall},
        {cell_wall, cell_free, cell_free, cell_free, cell_free, cell_free, cell_free, cell_wall},
        {cell_wall, cell_wall, cell_wall, cell_wall, cell_wall, cell_wall, cell_wall, cell_wall}
	};
	move = 0;
	player = 0;
	printf("\n|||||||||||||||\n\n");
	print_maze(maze,0,0);
	maze_move(maze, player, move);
	return;
}


/*
** main function for testing the functions...
**
*/
int main(void) {
	test_maze_move ();
	return (0);

} /* end main */
