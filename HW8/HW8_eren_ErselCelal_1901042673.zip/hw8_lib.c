
#include <stdio.h>
#include <stdlib.h>
#include "hw8_lib.h"

#define WORDSIZE 50
#define LENGTH 1002
#define N 3
/*==============================================PART1===========================================================*/

void add_string(char word[],char backup_reading[],int location,int length, int n){
	if(length==0){
		return;
	}
	else{
		backup_reading[location]==word[n];
		add_string(word,backup_reading,location+1,length-1,n+1);
	}
}

int copy_array(char reading[],char backup_reading[]){
	if(backup_reading[0]=='\0')
		return;
	else{
		reading[0]=backup_reading[0];
		copy_array(reading+1,backup_reading+1);
	}	
}

int check_every_char(char word[], char words_to_delete[],int length, int n){
	if(n==length){
		return 0;
	}
	if(word[n]!=words_to_delete[n]){
		return 1;
	}
	else if(word[n]==words_to_delete[n]){
		check_every_char(word,words_to_delete,length,n+1);
	}
}

int match_word(char word[],char words_to_delete[],int n){
    int length1,length2;
	length1 = find_length_of_string(word);
	length2 = find_length_of_string(words_to_delete);
	if(length1!=length2){
		return 1;
	}
	else if(check_every_char(word,words_to_delete,length1,0)==1){
		return 1;
	}
	else return 0;
}

int get_line(char* reading,int location, int counter, char words_to_delete[],char* backup_reading){
	char word[20]={'\0'};
	/* location and counter passed as 0 from check_word */
	if(reading[location]=='\n'||reading[location]=='\0'){
		printf("get_line bitti ");
		return;
	}
	else{
		location = get_word(reading,word,location,counter);
		
		printf("word %s checked by %s  | location is in get_line == %d\n",word,words_to_delete,location);
		
		if(match_word(word,words_to_delete,0)==1){
			add_string(word,backup_reading,location,find_length_of_string(word),0);
		}
		   		   
		get_line(reading,location,0,words_to_delete,backup_reading);  	
	}
}

int get_word(char* reading,char word[], int location,int counter){
	if(reading[location]==' '){
		return location+1;
	}
	else if(reading[location]=='\n'||reading[location]=='\0'){
		return location;
	}
	else{
		word[counter]=reading[location];
		get_word(reading,word,location+1,counter+1);
	}
}

int find_length_of_string(char *array){
	if(*array == '\0')
		return 0;
	
	return (1+find_length_of_string(++array));	
}

void check_word(char* reading,char words_to_delete[], char* backup_reading){
	

	/*reading'i gönderdik, silinmesi gereken bir kelime gönderdik. reading'in sonuna kadar her kelimeyi word'e kaydedip silinecek kelime ile kıyaslayacak.*/
	int location=0; /*readingte hangi indexte kaldığımızı tutacak */
	
	/* we will check until end of line by using get_line func */
	get_line(reading,0,0,words_to_delete,backup_reading);
                                                  /* boşluğa kadar reading'ten kelime alıp word'e kaydedecek */
	                                              /*kelimeyi word'e kaydettikten sonra bize reading'te kaldığı konum lazım */
											 
	/*
	check_char(reading, words_to_delete, length,0); /*word_to_delete ile eşleşip eşleşmedini kontrol edecek 
	                                                */ 
	return;
}

void remove_word(char reading[], char* words_to_delete[WORDSIZE],int number_of_words, int counter, FILE* outfid){
	char backup_reading[LENGTH] = {'\0'};
	if(counter==N){ /* it will return when there is no more words to delete */
		printf("----------remove word is over---------\n");
		return;
	}
	else{
		/*we send variables to func to checking */
		check_word(reading,words_to_delete[counter],backup_reading); 	
		printf("\n\n");
		
		copy_array(reading,backup_reading);
		/*backup_reading will be removed string array*/
		
		/**** write_output(outfid,backup_reading) ****/
		
		remove_word(reading,words_to_delete,number_of_words,counter+1,outfid);		
	}
}

void delete_words (FILE* infid, FILE* outfid, char* words_to_delete[WORDSIZE],  int number_of_words)
{
	char reading[LENGTH-2] = {'\0'};
    if(fgets(reading,LENGTH-2,infid)==0){
		printf("Dosya bitti ");
		return;
	}
	else{
		/*remove_word will run from 0 to number_of_words*/
		remove_word(reading,words_to_delete,number_of_words,0,outfid);

		/*removing words from new line*/	
		delete_words (infid, outfid, words_to_delete, number_of_words);
	}
}
void clean_file(char* infile, char * outfile, char* words_to_delete[WORDSIZE], int number_of_words)
{
	FILE* infid;
	FILE* outfid;
	
	/*open file */
	infid = fopen(infile, "r+"); 
	outfid = fopen(outfile,"w+");
	if(infid==NULL){
		printf("\nFILE COULDN'T OPEN");
	}
	if(outfid==NULL){
		printf("\nFILE COULDN'T OPEN");
	}
	delete_words (infid, outfid, words_to_delete, number_of_words);
	fclose(infid);
	fclose(outfid);
}

/*===================================================================================================================*/
/*=====================================================PART 2-MAZE====================================================*/

int check_move(cell_type maze[][8], cell_type player, move_type move, int row, int column){
	if(move==0){ /* 0 is left move */
		if(maze[row][column-1]==2) /*if desired move is target*/
		   return 5;
		if(maze[row][column-1]==1){ /*if desired move is free*/
			maze[row][column-1]=player;
			maze[row][column]=1;
			return 0;
		}
		else 
		  return 4;
	}
	else if(move==1){ /*1 is right move*/
		if(maze[row][column+1]==2) /*if desired move is target*/
		   return 5;
		if(maze[row][column+1]==1){ /*if desired move is free*/
			maze[row][column+1]=player;
			maze[row][column]=1;
			return 1;
		}
		else 
		  return 4;
	}
	else if(move==2){ /*2 is up move*/
		if(maze[row-1][column]==2) /*if desired move is target*/
		   return 5; 
		if(maze[row-1][column]==1){ /*if desired move is free*/
			maze[row-1][column]=player;
			maze[row][column]=1;
			return 2;
		}
		else 
		  return 4;
	}
	else if(move==3){ /*3 is up move*/
		if(maze[row+1][column]==2) /*if desired move is target*/
		   return 5;
		if(maze[row+1][column]==1){ /*if desired move is free*/
			maze[row+1][column]=player;
			maze[row][column]=1;
			return 3;
		}
	}
	else{
		return 4;
	}	  
}
int find_row(cell_type maze[][8], cell_type player, int i, int j){
	
	/*checking every index to find row index of player */
	if(j>7){
		j=0;
		i++;
		if(i>7){ 
			return;
		}
	}
	    if(maze[i][j]==player){
			return i;
		}
		else
		  find_row(maze,player,i,j+1);
}
int find_column(cell_type maze[][8], cell_type player, int i, int j){
	
	/*checking every index to find column index of player */
	if(j>7){
		j=0;
		i++;
		if(i>7){
			return;
		}
	}
	    if(maze[i][j]==player){
			return j;
		}
		else
		  find_column(maze,player,i,j+1);
}
void print_maze(cell_type maze[][8],int i,int j){
	
	/*printing X for walls and space for free*/
	if(j>7){
		printf("\n");
		j=0;
		i++;
		if(i>7){
			return;
		}
	}
		if(maze[i][j]==0) /*printing X for walls */
		printf("X ");
		if(maze[i][j]==1) /*printing space for free */
		printf("  ");
		if(maze[i][j]==2) /*printing T for target */
		printf("T ");
		if(maze[i][j]==3) /*printing 1 for player 1 */
		printf("1 ");
		if(maze[i][j]==4) /*printing 2 for player 2 */
		printf("2 ");
	    
		print_maze(maze,i,j+1); /*printing next column*/
}

int maze_move(cell_type maze[][8], cell_type player, move_type move)
{
	int flag,row,column;
	printf("\n|||||||||||||||\n\n");
	/* get player choice */
	printf("Enter which player you want to play | 1-P1 | 2-P2 | ENTER -1 STOP | >>> ");
	scanf("%u",&player);
	if(player==-1) /*stop condition*/
	   return;
	
	player = player + 2; 
	/* get movement choice */
	printf("\nEnter direction for P1 --> | 0-Left | 1-Right | 2-Up | 3-Down | >>> ");
	scanf("%u",&move);
	
	/* finding row and column index's by functions */
	row = find_row(maze,player,0,0);
	column = find_column(maze,player,0,0);
	
	/*check_move returns a value about validity of desired move*/
	move = check_move(maze,player,move,row,column);
	switch (move)
	{
		case move_left:
				printf("\nMOVEMENT LEFT SUCCESSFULL\n");
				printf("\n|||||||||||||||\n\n");
				print_maze(maze,0,0);
				maze_move(maze, player, move); /*calling function for new step*/
			    break;
		case move_right:
			    printf("\nMOVEMENT RIGHT SUCCESSFULL\n");
				printf("\n|||||||||||||||\n\n");
				print_maze(maze,0,0);
				maze_move(maze, player, move); /*calling function for new step*/
			    break;
		case move_up:
			    printf("\nMOVEMENT UP SUCCESSFULL\n");
				printf("\n|||||||||||||||\n\n");
				print_maze(maze,0,0);
				maze_move(maze, player, move); /*calling function for new step*/
			    break;
		case move_down:
		  	    printf("\nMOVEMENT DOWN SUCCESSFULL\n");
				printf("\n|||||||||||||||\n\n");
				print_maze(maze,0,0);
				maze_move(maze, player, move); /*calling function for new step*/
			    break;
		case 4:
		     printf("\nINVALID MOVEMENT\n");
			 maze_move(maze, player, move); /*calling function for new step*/
			 break;
		case 5:
		     /*if check_move returns 5, game is finished*/
			 printf("\n*-----------------------*\n");
			 printf("*     PLAYER %u WON      *\n",player-2);
			 printf("*-----------------------*\n");
			 return;
		case -1: 
		     return;	 
	}
	return -1;
}