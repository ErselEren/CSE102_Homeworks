/*
    I used math.h library to calculate probability, so add -lm when compiling
    -struct word_syn and struct word_ant keeps words from antonyms.txt and synonyms.txt
     also we keep int odds in this lists to calculate probability and decide which word will be asked
    -At the beginning odds of each word is 1. 
     In every question, program sum all odds and create an random number from 1 to sum. Then choose corresponding word.
     For example : Happy(odds=4), sad(odds=2), angry(odds=8). Then we create a number from 1 to 16(4+2+8). Let's say it is 5.
     Then we subtract odds of words one by one. If result is equal or less than 0, we choose that word. In this example, we choose "sad"
     When it ask a word:
     if user give incorrect answer program multiply it's odds by 2. if user give correct answer program divide it's odds by 2.
    -If user used program before, we update probabilities of words(multiple with 2) by using binary file of user. 
    -Program saves performance only for updating odds, not for printing.Because printing performance is not specified in PDF
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#define WORDSIZE 30

struct Words{
    char word[WORDSIZE];
    struct Words* next;
};

struct word_ant{
    int odds;
    char mainWord[WORDSIZE];
    struct Words *wordAnt;
    struct word_ant *link;
};

struct word_syn{
    int odds;
    char mainWord[WORDSIZE];
    struct Words *wordSyn;
    struct word_syn *link;
};
struct users{
    char nameOfUser[WORDSIZE];
    struct users *link;
};

struct userlog{
    char c;
    char word[WORDSIZE];
    int counter;
    int wrong;
    struct userlog *link;
};

void get_user_save(struct userlog **headLog,char *name);
int check_user_save(struct users **headUsers, char *name);
void words_function(char *antonyms, char* synonyms);
void get_lines(char *antonyms,struct word_ant **headAnt,char *synonyms,struct word_syn **headSyn);
void decompose_antonyms_to_list(char *p1,struct word_ant **headAnt);
void decompose_synonyms_to_list(char *p1,struct word_syn **headSyn);
void read_user(struct users **headUsers);
void print_users(struct users **headUsers);
void add_user_to_file(char *name);
void add_new_word_syn(struct word_syn **headSyn);
void add_new_word_ant(struct word_ant **headAnt);
void check_answer_syn(struct word_syn **headSyn,struct userlog **headLog,char *answer, char *mainWord);
void check_answer_ant(struct word_ant **headAnt,struct userlog **headLog,char *answer, char *mainWord);
void print_antonym(struct word_ant **headAnt);
void print_synonym(struct word_syn **headSyn);
void write_files(struct userlog **headLog,struct word_syn **headSyn,struct word_ant **headAnt,char *name, char *antonyms, char *synonyms);
void update_odds(struct userlog **headLog,struct word_syn **headSyn,struct word_ant **headAnt);
int calculate_probability_syn(struct word_syn **headSyn);
int calculate_probability_ant(struct word_ant **headAnt);
int calc_ant_or_syn(struct userlog **headLog,int *countAnt,int *countSyn);

int main(){
    char *antonyms = "antonyms.txt";
    char *synonyms = "synonyms.txt";
    /*calling our function that we make operations*/
    words_function(antonyms,synonyms);
    return 0;
}

void words_function(char *antonyms, char* synonyms){
    /*for calculating odds*/
     srand(time(NULL));
    /*-------------------declaring variables----------------------*/
     int flag = 0,command,countAnt=0,countSyn=0,random,input;
     char name[WORDSIZE],answer[WORDSIZE];
     struct Words *ptrWord = NULL;
     struct userlog *ptrLog = NULL;
     struct userlog buffer;
     FILE *userfp,*fp1;
    /*------------------creating Antonym list---------------------*/
     struct word_ant *headAnt = calloc(1,sizeof(struct word_ant));
     struct word_ant *ptrAnt = NULL;
     headAnt->wordAnt = calloc(1,sizeof(struct Words));
     headAnt->wordAnt->next = NULL;
     headAnt->link = NULL; headAnt->odds = 1;
     strcpy(headAnt->mainWord,"mainWordAnt");
    /*-------------------creating Synonym list--------------------*/
     struct word_syn *headSyn = calloc(1,sizeof(struct word_syn));
     struct word_syn *ptrSyn = NULL;
     headSyn->wordSyn = calloc(1,sizeof(struct Words));
     headSyn->wordSyn->next = NULL;
     headSyn->link = NULL; headSyn->odds = 1;
     strcpy(headSyn->mainWord,"mainWordSyn");
    /*---------------------creating LOG list----------------------*/
     struct userlog *headLog = calloc(1,sizeof(struct userlog));
     strcpy(headLog->word,"headOfLogs");
     headLog->counter = 0;
     headLog->wrong = 0;
     headLog->c = 'c';
     headLog->link = NULL;
    /*-------------------------READ FILE INTO LIST-------------------------------*/
     get_lines(antonyms,&headAnt,synonyms,&headSyn);
    /*-------------------------reading users from file---------------------------*/
     struct users *headUsers = calloc(1,sizeof(struct users));
     struct users *ptrUsers = NULL;
     read_user(&headUsers);
     print_users(&headUsers);
    /*---------------------------getting user's name-----------------------------*/
     printf("\n Enter an user name : ");
     scanf("%s",name);
     flag = check_user_save(&headUsers,name);
    /*-----------------checking user if he/she has a save file-------------------*/
     if(flag==1){ /*this user already used program before*/
         printf("\nThere is a file for this user.");
         strcat(name,".worddat");
         /*getting previous performance of user*/
          get_user_save(&headLog,name);
     }
     if(flag==0){ /*we have new user*/
         printf("\nThere isn't any file for this user. Creating new one...");
         ptrUsers = headUsers;
         ptrUsers->link = calloc(1,sizeof(struct users));
         ptrUsers->link->link = NULL;
         strcpy(ptrUsers->link->nameOfUser,name);
         add_user_to_file(name);   
     }
     /*according to binary files, we update odds(probability) in the words list*/
     update_odds(&headLog,&headSyn,&headAnt);
    /*//////////////After this line, odds of words is ready to use and calculate probability\\\\\\\\\\\\\\*/
    
    while(1){
        printf("\n 1-Ask Question\n 2-Add New Word \n 3-EXIT\n------->");
        scanf("%d",&input);
        if(input==3){
            break;
        }
        else if(input==1){
            /*this function decides to ask antonym or synonym*/
            flag = calc_ant_or_syn(&headLog,&countAnt,&countSyn);
            if(flag==0){/*synoynm*/
            
            /*this function decides which word will be asked*/
            random = calculate_probability_syn(&headSyn);
            
            /*----------print synonyms list-----------*/
             ptrSyn = headSyn->link;
             while(1){
                if(ptrSyn->link==NULL) break;
                    ptrSyn = ptrSyn->link;
                }
            /*------select a word according to probability-----*/
             ptrSyn = headSyn->link;
             while(1){
                if(random-(ptrSyn->odds)<=0) break;
                if(ptrSyn->link==NULL) break;
                random = random - ptrSyn->odds;
                ptrSyn = ptrSyn->link;
             }
            printf("\n What is the synonym of %s ?\n-------> ",ptrSyn->mainWord);
            scanf("%s",answer);
            /*here we make other operations in this function*/
            check_answer_syn(&headSyn,&headLog,answer,ptrSyn->mainWord);
            }
            if(flag==1){/*antonym*/
              /*this function decides which word will be asked*/
              random = calculate_probability_ant(&headAnt);
              /*----------print antonyms list-----------*/
                ptrAnt = headAnt->link;
                while(1){
                  if(ptrAnt->link==NULL) break;
                    ptrAnt = ptrAnt->link;
                  }
            /*------select a word according to probability-----*/
             ptrAnt = headAnt->link;
             while(1){
                if(random-(ptrAnt->odds)<=0) break;
                if(ptrAnt->link==NULL) break;
                random = random - ptrAnt->odds;
                ptrAnt = ptrAnt->link;
             }
             printf("\n What is the antonym of %s ?\n-------> ",ptrAnt->mainWord);
             scanf("%s",answer);
             /*here we make other operations in this function*/
             check_answer_ant(&headAnt,&headLog,answer,ptrAnt->mainWord);
            } 
        }
        else if(input==2){
            printf("\nWhich list do you want to add? \n 1-Antonym\n 2-Synonym\n----> ");
            scanf("%d",&input);
            if(input==1) add_new_word_ant(&headAnt);
            if(input==2) add_new_word_syn(&headSyn);  
        }
         
    }
    /*-------After exiting while loop, we are writing our datas to files-------*/
      printf("\n %s is updated\n-----------------END OF PROGRAM-----------------",name);
      write_files(&headLog,&headSyn,&headAnt,name,antonyms,synonyms);

      /*-------------------------freeing list--------------------------*/
      struct word_ant *tempAnt = NULL;
      tempAnt = headAnt;
      ptrAnt = headAnt;
      tempAnt = tempAnt->link;
      while(1){
          free(ptrAnt);
          if(tempAnt->link==NULL)break;
          tempAnt = tempAnt->link;
          ptrAnt = ptrAnt->link;
      }
      struct word_syn *tempSyn = NULL;
      tempSyn = headSyn;
      ptrSyn = headSyn;
      tempSyn = tempSyn->link;
      while(1){
          free(ptrSyn);
          if(tempSyn->link==NULL)break;
          tempSyn = tempSyn->link;
          ptrSyn = ptrSyn->link;
      }  
}

void add_new_word_ant(struct word_ant **headAnt){
    int flag = 0;
    char new_word[WORDSIZE];
    struct word_ant *ptrAnt = NULL;
    struct Words *ptrWord = NULL;
    
    printf("\nEnter the word that you want to add antonym to it : ");
    scanf("%s",new_word);
    ptrAnt = *headAnt;
    while(1){/*find taken word in list*/
        if(strcmp(ptrAnt->mainWord,new_word)==0){
            flag = 1;
            break;
        }
        if(ptrAnt->link == NULL)break;
        ptrAnt = ptrAnt->link;
    }
    if(flag==1){ /*get new antonym for it*/
        printf("\nEnter a antonym word for %s : ",new_word);
        scanf("%s",new_word);
        ptrWord = ptrAnt->wordAnt;
        while(1){
            if(ptrWord->next==NULL) break;
            ptrWord = ptrWord->next;
        }
        ptrWord->next = calloc(1,sizeof(struct Words)); /*allocating new memory for new word*/
        ptrWord = ptrWord->next;
        ptrWord->next = NULL;
        strcpy(ptrWord->word,new_word);

    }
    if(flag==0){ /*if entered words is not exist in the list*/
        printf("\n!!THIS WORD IS NOT EXISTING IN THE LIST!!");
    }
}

void add_new_word_syn(struct word_syn **headSyn){
    int flag = 0;
    char new_word[WORDSIZE];
    struct word_syn *ptrSyn = NULL;
    struct Words *ptrWord = NULL;
    
    printf("\nEnter the word that you want to add synonym to it : ");
    scanf("%s",new_word);
    ptrSyn = *headSyn;
    while(1){ /*find taken word in list*/
        if(strcmp(ptrSyn->mainWord,new_word)==0){
            flag = 1;
            break;
        }
        if(ptrSyn->link == NULL)break;
        ptrSyn = ptrSyn->link;
    }
    if(flag==1){ /*get new synonym for it*/
        printf("\nEnter a synonym word for %s : ",new_word);
        scanf("%s",new_word);
        ptrWord = ptrSyn->wordSyn;
        while(1){
            if(ptrWord->next==NULL) break;
            ptrWord = ptrWord->next;
        }
        ptrWord->next = calloc(1,sizeof(struct Words));/*allocating new memory for new word*/
        ptrWord = ptrWord->next;
        ptrWord->next = NULL;
        strcpy(ptrWord->word,new_word);

    }
    if(flag==0){ /*if entered words is not exist in the list*/
        printf("\n!!THIS WORD IS NOT EXISTING IN THE LIST!!");
    }
}

int check_user_save(struct users **headUsers, char *name){
     struct users *ptrUsers = NULL;
     ptrUsers = *headUsers;
     while(1){ /*searching user name in the list that we get from username.txt*/
         if(strncmp(name,ptrUsers->nameOfUser,strlen(ptrUsers->nameOfUser))==0){
             return 1;
         }
         if(ptrUsers->link==NULL)return 0;
         ptrUsers = ptrUsers->link;
     }
}

void read_user(struct users **headUsers){
    FILE *userfp = fopen("username.txt","r");
    struct users *ptrUsers = NULL;
    ptrUsers = *headUsers;
    strcpy((*headUsers)->nameOfUser,"usersname");
    if(userfp == NULL){
        printf("FILE COULDN'T OPEN");
    }
    else{/*getting username's from username.txt*/
        while(fscanf(userfp,"%s",ptrUsers->nameOfUser)!=EOF){
            if(ptrUsers->link == NULL){
                ptrUsers->link = calloc(1,sizeof(struct users));  
                ptrUsers = ptrUsers->link;
                ptrUsers->link == NULL;
            }
        }
        fclose(userfp);
    }

    /*-------freeing last empty node-------*/
     if((*headUsers)->link!=NULL){
        ptrUsers = *headUsers;
        while(1){
            if(ptrUsers->link->link==NULL){
                free(ptrUsers->link);
                ptrUsers->link = NULL;
                break;
            }
            ptrUsers = ptrUsers->link;
        }
     }
}

void get_lines(char *antonyms,struct word_ant **headAnt,char *synonyms,struct word_syn **headSyn){
    
    char c;
    char *p1,*p2=NULL;
    int i,length,flag;
    flag = 1; length = 0;

    FILE *fp = fopen(antonyms,"r");
    if(fp == NULL){
        printf("File couldn't open ");
    }
    
    /*============================ANTONYM================================*/
    while(flag==1){  
          c = fgetc(fp);
          length++;
          
          /*EOF control*/
          if(c==EOF) flag = 0;
          
          /*when it reads new line, decompose it*/
          if(c=='\n'){
             decompose_antonyms_to_list(p1,headAnt);
             length=0;
          }
          /*reading and allocating memory for each character that we read*/
           if(c!=EOF&&c!='\n'&&c!='\r'){ 
             p1 = calloc(length+1,sizeof(char));
             for(i=0;i<length-1;i++) p1[i] = p2[i];
             
             p1[length-1] = c;
             
             if(p2!=NULL) free(p2);
             
             p2 = p1;  
           }
    }
    
    /*============================SYNONYM================================*/
    fp = fopen(synonyms,"r");
    if(fp == NULL){
        printf("File couldn't open ");
    }
    flag = 1; length = 0;
    p2 = NULL;

    while(flag==1){  
          c = fgetc(fp);
          length++;
          
          /*EOF control*/
          if(c==EOF) flag = 0;
          
          /*when it reads new line, decompose it*/
          if(c=='\n'){
             decompose_synonyms_to_list(p1,headSyn);
             length=0;
          }
          /*reading and allocating memory for each character that we read*/
           if(c!=EOF&&c!='\n'&&c!='\r'){ 
             p1 = calloc(length+1,sizeof(char));
             for(i=0;i<length-1;i++) p1[i] = p2[i];
             
             p1[length-1] = c;
             
             if(p2!=NULL) free(p2);
             
             p2 = p1;  
           }
    }
    
    fclose(fp);
}

void decompose_antonyms_to_list(char *p1,struct word_ant **headAnt){
    
    struct Words *ptrWords = NULL; /*this pointer follows antonyms of word*/
    struct word_ant *ptrAnt = NULL;/*this pointer follows main list */
    
    /*creating new node to decompose new*/
    struct word_ant *node = calloc(1,sizeof(struct word_ant));/*we decompose list into this node*/
    node->wordAnt = calloc(1,sizeof(struct Words));
    node->odds = 1;
    node->wordAnt->next = NULL;
    node->link = NULL;

    
    ptrWords = node->wordAnt;
    ptrAnt = *headAnt;
    /*we linked new node to end of the list*/
    while(1){
        if(ptrAnt->link == NULL){
            ptrAnt->link = node;
            break;
        }
        ptrAnt = ptrAnt->link;
    }
   
    /*--------we got main word-------*/
    int i=0;
    while(1){
        if(p1[i]==' '){
           break; 
        }
        i++;
    }
    strncpy(node->mainWord,p1,i);
    node->mainWord[strlen(node->mainWord)]='\0';
    p1 = p1+i+4;
    /*---------------------------------------*/
    
    /*============then filling node============*/
    i=0;
    while(1){
        if(p1[i]=='\0'||p1[i]==' '){
            strncpy(ptrWords->word,p1,i);
            ptrWords->word[strlen(ptrWords->word)]='\0';
           
            if(p1[i]=='\0'){
                break;
            }else{
                p1 = p1+i+1;
                i=0;
                ptrWords->next = calloc(1,sizeof(struct Words));
                ptrWords = ptrWords->next;
                ptrWords->next = NULL;
            }
        }
        i++;
    }
    
}

void decompose_synonyms_to_list(char *p1,struct word_syn **headSyn){

    struct Words *ptrWords = NULL; /*this pointer follows antonyms of word*/
    struct word_syn *ptrSyn = NULL;/*this pointer follows main list */
    
    
    /*creating new node to decompose new*/
      struct word_syn *node = calloc(1,sizeof(struct word_syn));/*line'ı bu node'a decompose edeceğiz*/
      node->wordSyn = calloc(1,sizeof(struct Words));
      node->odds = 1;
      node->wordSyn->next = NULL;
      node->link = NULL;


    ptrWords = node->wordSyn;
    ptrSyn = *headSyn;
    /*we linked new node to end of the list*/
    while(1){
        if(ptrSyn->link == NULL){
            ptrSyn->link = node;
            break;
        }
        ptrSyn = ptrSyn->link;
    }
    
    /*--------we got main word-------*/
    int i=0;
    while(1){
        if(p1[i]==' '){
           break; 
        }
        i++;
    }
    strncpy(node->mainWord,p1,i);
    node->mainWord[strlen(node->mainWord)]='\0';
    p1 = p1+i+3;
    /*---------------------------------------*/
    
    /*=================then filling node====================*/
    i=0;
    while(1){
        if(p1[i]=='\0'||p1[i]==' '){
            strncpy(ptrWords->word,p1,i);
            ptrWords->word[strlen(ptrWords->word)]='\0';
            if(p1[i]=='\0'){
                break;
            }else{
                p1 = p1+i+1;
                i=0;
                ptrWords->next = calloc(1,sizeof(struct Words));
                ptrWords = ptrWords->next;
                ptrWords->next = NULL;
            }
        }
        i++;
    }
  
}

void print_users(struct users **headUsers){
    /*---------------printing names------------------*/
    struct users *ptrUsers = NULL;
    ptrUsers = *headUsers;
    while(1){
        printf("\n-----> %s",ptrUsers->nameOfUser);
        if(ptrUsers->link == NULL){
            break;
        }
        ptrUsers = ptrUsers->link;
    }
}

void add_user_to_file(char *name){
    /*--here we add new user's name into username.txt--*/
         FILE *userfp = fopen("username.txt","a+");
         if(userfp == NULL){
            printf("FILE COULDN'T OPEN");
         }else{
             fprintf(userfp,"%s%c",name,'\n');
         }
         fclose(userfp);
         
         /*--creating binary file--*/
           strcat(name,".worddat");
           userfp = fopen(name,"w+");
           fclose(userfp);
         /*---------------------------*/ 
}

int calculate_probability_syn(struct word_syn **headSyn){
    struct word_syn *ptrSyn = NULL;
    int sum;
    /*-----summing odds of all word's in the list-----*/
        ptrSyn = *headSyn;
        sum = -1;
        while(1){
           sum += ptrSyn->odds;
           if(ptrSyn->link==NULL) break;
           ptrSyn = ptrSyn->link;
        }
    /*then we return a number from 1 to sum*/
    return rand()%sum+1;
}

int calculate_probability_ant(struct word_ant **headAnt){
    struct word_ant *ptrAnt = NULL;
    int sum;
    /*-----summing odds of all word's in the list-----*/
        ptrAnt = *headAnt;
        sum = -1;
        while(1){
           sum += ptrAnt->odds;
           if(ptrAnt->link==NULL) break;
           ptrAnt = ptrAnt->link;
        }
    /*then we return a number from 1 to sum*/    
    return rand()%sum+1;
}

void check_answer_syn(struct word_syn **headSyn,struct userlog **headLog,char *answer, char *mainWord){
    /*------declaring variables-------*/
    int flag = 0, choice;
    struct word_syn *ptrSyn = NULL;
    struct Words *ptrWord = NULL;
    struct userlog *ptrLog;
    /*--------------------------------*/
    ptrSyn = *headSyn;
    
    while(1){ /*first we find our mainword in the list*/
        if(strcmp(ptrSyn->mainWord,mainWord)==0){
            break;
        }
        ptrSyn = ptrSyn->link;
    }
    
    ptrWord = ptrSyn->wordSyn;
    while(1){/*then searching user's answer for mainword's synonyms*/
        if(strcmp(ptrWord->word,answer)==0){
            if(ptrSyn->odds!=1){
                ptrSyn->odds = ptrSyn->odds/2;
            }
            flag = 1;
            break;
        }
        if(ptrWord->next==NULL) break;
        ptrWord = ptrWord->next;
    }
    if(flag == 1){
        printf("\n |+|+|CORRECT ANSWER|+|+|");
           /*then we find this word in user log list and increment counter*/
            flag = 0;
            ptrLog = *headLog;
            while(1){
                if(ptrLog->c == 's'&& (strcmp(ptrLog->word,mainWord)==0)){
                    flag = 1;
                    ptrLog->counter++;
                    break;
                }
                if(ptrLog->link==NULL)break;
                ptrLog = ptrLog->link;
            }
            if(flag==0){ /*if this word is asked for the first time, create new node*/
                ptrLog->link=calloc(1,sizeof(struct userlog));
                ptrLog = ptrLog->link;
                ptrLog->link = NULL;
                strcpy(ptrLog->word,mainWord);
                ptrLog->c = 's'; ptrLog->counter = 1; ptrLog->wrong = 0;
            }
    }
    else{
        printf("\nYour answer is not in the list. Would you like to add it to list?\n 1-Yes\n 2-No\n---->");
        scanf("%d",&choice);
        if(choice==1){ /*user decided to add answer to list*/
            /*---------we add user's answer to the list---------*/
            ptrSyn = *headSyn;
            while(1){
                if(strcmp(ptrSyn->mainWord,mainWord)==0){
                    if(ptrSyn->odds!=1){
                        ptrSyn->odds = ptrSyn->odds/2;
                    }
                    break;
                }
                ptrSyn = ptrSyn->link;
            }
            ptrWord = ptrSyn->wordSyn;
            while(1){
                if(ptrWord->next==NULL) break;
                ptrWord = ptrWord->next;
            }
            ptrWord->next = calloc(1,sizeof(struct Words));
            ptrWord = ptrWord->next;
            ptrWord->next = NULL;
            strncpy(ptrWord->word,answer,strlen(answer));
            /*-----------------------------------------------*/
            flag = 0;
            ptrLog = *headLog;
            while(1){/*increment user log's counter*/
                if((ptrLog->c == 's')&&(strcmp(ptrLog->word,mainWord)==0)){
                    flag = 1;
                    ptrLog->counter++;
                    break;
                }
                if(ptrLog->link==NULL)break;
                ptrLog = ptrLog->link;
            }
            if(flag==0){
                ptrLog->link=calloc(1,sizeof(struct userlog));
                ptrLog = ptrLog->link;
                ptrLog->link = NULL;
                strcpy(ptrLog->word,mainWord);
                ptrLog->c = 's'; ptrLog->counter = 1; ptrLog->wrong = 0;
            }

        }
        if(choice==2){ /*user accepts answer is wrong*/
            /*then we increment counter and false variables in user log*/
            ptrLog = *headLog;
            flag = 0;
            while(1){
                if(ptrLog->c == 's'&& (strcmp(ptrLog->word,mainWord)==0)){
                    flag = 1;
                    ptrLog->counter++;
                    ptrLog->wrong++;
                    break;
                }
                if(ptrLog->link==NULL)break;
                ptrLog = ptrLog->link;
            }
            if(flag==0){
                ptrLog->link=calloc(1,sizeof(struct userlog));
                ptrLog = ptrLog->link;
                ptrLog->link = NULL;
                strcpy(ptrLog->word,mainWord);
                ptrLog->c = 's'; ptrLog->counter = 1; ptrLog->wrong = 1;
            }
            
            /*increment probability of this word*/
            ptrSyn = *headSyn;
            ptrSyn = ptrSyn->link;
            while(1){
                if(strcmp(ptrSyn->mainWord,mainWord)==0)
                    ptrSyn->odds = ptrSyn->odds*2;     
                if(ptrSyn->link==NULL)break;
                ptrSyn = ptrSyn->link;
            }
        }   
    }
}

void check_answer_ant(struct word_ant **headAnt,struct userlog **headLog,char *answer, char *mainWord){
    /*------declaring variables-------*/
    int flag = 0, choice;
    struct word_ant *ptrAnt = NULL;
    struct Words *ptrWord = NULL;
    struct userlog *ptrLog;
    /*--------------------------------*/
    ptrAnt = *headAnt;
    while(1){ /*first we find our mainword in the list*/
        if(strcmp(ptrAnt->mainWord,mainWord)==0){
            break;
        }
        ptrAnt = ptrAnt->link;
    }
    ptrWord = ptrAnt->wordAnt;
    while(1){ /*then searching user's answer for mainword's synonyms*/
        if(strcmp(ptrWord->word,answer)==0){
            if(ptrAnt->odds!=1){
                ptrAnt->odds = ptrAnt->odds/2;
            }
            flag = 1;
            break;
        }
        if(ptrWord->next==NULL) break;
        ptrWord = ptrWord->next;
    }
    if(flag == 1){
        printf("\n |+|+|CORRECT ANSWER|+|+|");
          /*then we find this word in user log list and increment counter*/
            flag = 0;
            ptrLog = *headLog;
            while(1){
                if(ptrLog->c == 'a'&& (strcmp(ptrLog->word,mainWord)==0)){
                    flag = 1;
                    ptrLog->counter++;
                    break;
                }
                if(ptrLog->link==NULL)break;
                ptrLog = ptrLog->link;
            }
            if(flag==0){/*if this word is asked for the first time, create new node*/
                ptrLog->link=calloc(1,sizeof(struct userlog));
                ptrLog = ptrLog->link;
                ptrLog->link = NULL;
                strcpy(ptrLog->word,mainWord);
                ptrLog->c = 'a'; ptrLog->counter = 1; ptrLog->wrong = 0;
            }
    }
    else{
        printf("\nYour answer is not in the list. Would you like to add it to list?\n 1-Yes\n 2-No\n---->");
        scanf("%d",&choice);
        if(choice==1){/*user decided to add answer to list*/
            /*---------we add user's answer to the list---------*/
            ptrAnt = *headAnt;
            while(1){
                if(strcmp(ptrAnt->mainWord,mainWord)==0){
                    if(ptrAnt->odds!=1){
                        ptrAnt->odds = ptrAnt->odds/2;
                    }
                    break;
                }
                ptrAnt = ptrAnt->link;
            }
            ptrWord = ptrAnt->wordAnt;
            while(1){
                if(ptrWord->next==NULL) break;
                ptrWord = ptrWord->next;
            }
            ptrWord->next = calloc(1,sizeof(struct Words));
            ptrWord = ptrWord->next;
            ptrWord->next = NULL;
            strcpy(ptrWord->word,answer);
            /*-----------------------------------------------*/
            flag = 0;
            ptrLog = *headLog;
            while(1){ /*increment user log's counter*/
                if(ptrLog->c == 'a'&& (strcmp(ptrLog->word,mainWord)==0)){
                    flag = 1;
                    ptrLog->counter++;
                    break;
                }
                if(ptrLog->link==NULL)break;
                ptrLog = ptrLog->link;
            }
            if(flag==0){
                ptrLog->link=calloc(1,sizeof(struct userlog));
                ptrLog = ptrLog->link;
                ptrLog->link = NULL;
                strcpy(ptrLog->word,mainWord);
                ptrLog->c = 'a'; ptrLog->counter = 1; ptrLog->wrong = 0;
            }

        }
        if(choice==2){/*user accepts answer is wrong*/
            /*then we increment counter and false variables in user log*/
            ptrLog = *headLog;
            flag = 0;
            while(1){
                if(ptrLog->c == 'a'&& (strcmp(ptrLog->word,mainWord)==0)){
                    flag = 1;
                    ptrLog->counter++;
                    ptrLog->wrong++;
                    break;
                }
                if(ptrLog->link==NULL)break;
                ptrLog = ptrLog->link;
            }
            if(flag==0){
                ptrLog->link=calloc(1,sizeof(struct userlog));
                ptrLog = ptrLog->link;
                ptrLog->link = NULL;
                strcpy(ptrLog->word,mainWord);
                ptrLog->c = 'a'; ptrLog->counter = 1; ptrLog->wrong = 1;
            }
            /*increment probability of this word*/
            ptrAnt = *headAnt;
            ptrAnt = ptrAnt->link;
            while(1){
                if(strcmp(ptrAnt->mainWord,mainWord)==0)
                    ptrAnt->odds = ptrAnt->odds*2;     
                if(ptrAnt->link==NULL)break;
                ptrAnt = ptrAnt->link;
            }
        }   
    }
}

void get_user_save(struct userlog **headLog,char *name){
    FILE *fp1;
    struct userlog *ptrLog = NULL;
    /*opening username.worddat file to get previous performance of user*/
    fp1 = fopen(name,"rb"); 
        ptrLog = *headLog;
        while(1){/*reading into linked list from file*/
          if(fread(ptrLog,sizeof(struct userlog),1,fp1)==0){
                break;
          }
          ptrLog->link = calloc(1,sizeof(struct userlog));
          ptrLog = ptrLog->link;
          ptrLog->counter = -1;
          ptrLog->link = NULL;
        } 
        fclose(fp1);
}

int calc_ant_or_syn(struct userlog **headLog,int *countAnt,int *countSyn){
    struct userlog *ptrLog = NULL;
    int random;
    ptrLog = *headLog;
        while(1){
            if(ptrLog->c=='s')(*countAnt)++;
            if(ptrLog->c=='a')(*countSyn)++;
            if(ptrLog->link==NULL)break;
            ptrLog = ptrLog->link;
        }
        /*here we count number of asked synonym and antonyms
          if in previous session we asked 7 synonym and 4 antonym, we assume that:
          we will choose through 4 synonym and 7 antonym so that we increased probability of antonyms
          so our selection pool is a-a-a-a-a-a-a-s-s-s-s, 
          then we create random number from 1 to 11(sum of ant and syn)*/
        if((*countAnt+*countSyn)!=0){
            random = rand()%(*countAnt+*countSyn)+1;
            if((*countAnt-random)>=0){
                return 1;/*antonym*/
            } 
            else return 0;/*synonym*/
        }
        else{
            return 0;
        }
}

void write_files(struct userlog **headLog,struct word_syn **headSyn,struct word_ant **headAnt,char *name, char *antonyms, char *synonyms){
    FILE *fp1 = NULL;
    struct userlog *ptrLog = NULL;
    struct word_syn *ptrSyn = NULL;
    struct word_ant *ptrAnt = NULL;
    struct Words *ptrWord = NULL;
    char charNewline = '\n';
    /*------------writing to binary file--------------*/
    fp1 = fopen(name,"wb");
    ptrLog = *headLog;
        while(1){
           if(ptrLog->c=='c'||ptrLog->c=='a'||ptrLog->c=='s'){
               fwrite(ptrLog,sizeof(struct userlog),1,fp1);
           }
           if(ptrLog->link==NULL) break;
           ptrLog = ptrLog->link;
        }
    fclose(fp1);
    printf("\n\n");
    
    /*--------------writing to texts------------------*/
    fp1 = fopen(synonyms,"w");
    ptrSyn = (*headSyn)->link;
    while(1){
        fprintf(fp1,"%s =",ptrSyn->mainWord);
        ptrWord = ptrSyn->wordSyn;
        while(1){
            fprintf(fp1," %s",ptrWord->word);
            if(ptrWord->next==NULL){
                fprintf(fp1,"%c",charNewline);
                break;
            }    
            ptrWord = ptrWord->next;
        }
        if(ptrSyn->link==NULL) break;
        ptrSyn = ptrSyn->link;
    }
    fclose(fp1);
    
    fp1 = fopen(antonyms,"w");
    ptrAnt = (*headAnt)->link;
    while(1){
        fprintf(fp1,"%s <>",ptrAnt->mainWord);
        ptrWord = ptrAnt->wordAnt;
        while(1){
            fprintf(fp1," %s",ptrWord->word);
            if(ptrWord->next==NULL){
                fprintf(fp1,"%c",charNewline);
                break;
            }    
            ptrWord = ptrWord->next;
        }
        if(ptrAnt->link==NULL) break;
        ptrAnt = ptrAnt->link;
    }
    fclose(fp1);
    /*------------------------------------------------*/

}

void update_odds(struct userlog **headLog,struct word_syn **headSyn,struct word_ant **headAnt){
    struct userlog *ptrLog = NULL;
    struct word_syn *ptrSyn = NULL;
    struct word_ant *ptrAnt = NULL;
    ptrLog = *headLog;
    /*here we update odds of words by using previous performance of user*/
    while(1){ 
        if(ptrLog->c=='a'){ /*if char is a, search in the antonyms*/
            ptrAnt = *headAnt;
            while(1){
                if(strcmp(ptrAnt->mainWord,ptrLog->word)==0){
                    if(ptrLog->wrong!=0){
                        ptrAnt->odds = pow(2,ptrLog->wrong);/*we increment probibality of words 2 times for each wrong answer*/ 
                    }        
                } 
                if(ptrAnt->link==NULL)break;
                ptrAnt = ptrAnt->link;
            }
        }
        if(ptrLog->c=='s'){/*if char is s, search in the synonyms*/
            ptrSyn = *headSyn;
            while(1){
                if(strcmp(ptrSyn->mainWord,ptrLog->word)==0){
                    if(ptrLog->wrong!=0){
                        ptrSyn->odds = pow(2,ptrLog->wrong); /*we increment probibality of words 2 times for each wrong answer*/
                    }    
                } 
                if(ptrSyn->link==NULL)break;
                ptrSyn = ptrSyn->link;
            }
        }
        if(ptrLog->link==NULL)break;
        ptrLog = ptrLog->link;
    }

}
